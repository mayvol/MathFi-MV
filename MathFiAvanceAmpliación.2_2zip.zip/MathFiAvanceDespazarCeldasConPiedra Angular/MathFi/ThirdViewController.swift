//
//  ThirdViewController.swift
//  MathFi
//
//  Created by Macbook on 3/22/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    @IBOutlet weak var tabla1: UITableView!
    
    var Cursos: [Materias] = [
        Materias(nombre: "Aritmética"), Materias(nombre: "Álgebra"), Materias(nombre: "Trigonométria"), Materias(nombre: "Cálculo Diferencial"), Materias(nombre: "Cálculo Integral"), Materias(nombre: "Cálculo Vectorial")
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabla1.backgroundColor = .clear
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Cursos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1 = tableView.dequeueReusableCell(withIdentifier: "celda1", for: indexPath)
        cell1.backgroundColor = .clear
        cell1.textLabel?.font = UIFont(name:"Noteworthy", size: 22)
        cell1.textLabel?.text = Cursos[indexPath.row].nombre
        return cell1
    }


}
