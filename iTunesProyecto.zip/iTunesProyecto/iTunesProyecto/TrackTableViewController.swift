//
//  TrackTableViewController.swift
//  iTunesProyecto
//
//  Created by Macbook on 3/20/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit

class TrachTableViewController: UITableViewController{
    var tracks:[String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = .blue
        getTracks()
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tracks.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Celda", for: indexPath)
        cell.textLabel?.text = tracks[indexPath.row]
        return cell
        }

    func getTracks(){
        let url = URL(string: "https://itunes.apple.com/search?term=mecano")//get dame esta página
        
        let jsonDecoder = JSONDecoder()
        
        let tarea = URLSession.shared.dataTask(with: url!) { (data, response, error)/*me puede debolver datos,responder "" */ in
            
            if let data = data, let results = try? jsonDecoder.decode(Results.self, from: data){
                //preparas la cartuchera para disparar
                for track in results.results{
                    print(track.trackName)
                    self.tracks.append(track.trackName)
                }
                DispatchQueue.main.async {
                    self.tableView.reloadData()}
            }
        } //preparar la conexion al exterior
        
        tarea.resume()
    }
}
