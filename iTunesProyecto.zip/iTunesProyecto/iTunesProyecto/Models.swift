//
//  Models.swift
//  iTunesProyecto
//
//  Created by Macbook on 3/20/19.
//  Copyright © 2019 Theranos. All rights reserved.
//

import UIKit
struct Results: Codable{
    var resultCount: Int
    var results: [Track]
}

struct Track: Codable{
    var trackName: String
}
